:orphan:

Messaging in IPython
====================

The message specification is now part of Jupyter - see
:ref:`jupyterclient:messaging` for the documentation.
